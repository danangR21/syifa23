from __future__ import annotations
import json, sqlite3, hashlib
from pathlib import Path
from datetime import datetime
from io import BytesIO
import pandas as pd

def migrate_schema(db_path: Path):
    db_path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(db_path) as con:
        con.execute("""CREATE TABLE IF NOT EXISTS schema_migrations(
            version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL, description TEXT)""")
        con.execute("""CREATE TABLE IF NOT EXISTS audit_findings(
            finding_id TEXT PRIMARY KEY, run_id TEXT NOT NULL, category TEXT,
            severity TEXT, finding_json TEXT NOT NULL)""")
        con.execute("""CREATE TABLE IF NOT EXISTS qc_approvals(
            approval_id TEXT PRIMARY KEY, run_id TEXT NOT NULL, reviewer TEXT NOT NULL,
            status TEXT NOT NULL, remarks TEXT, approved_at TEXT NOT NULL)""")
        con.execute("""CREATE TABLE IF NOT EXISTS report_history(
            report_id TEXT PRIMARY KEY, run_id TEXT NOT NULL, report_type TEXT NOT NULL,
            file_name TEXT NOT NULL, created_at TEXT NOT NULL, approval_status TEXT)""")
        con.execute("""CREATE TABLE IF NOT EXISTS multi_site_batches(
            batch_id TEXT PRIMARY KEY, created_at TEXT NOT NULL, area TEXT,
            selected_sites TEXT NOT NULL, completed INTEGER DEFAULT 0,
            failed INTEGER DEFAULT 0, result_json TEXT)""")
        con.execute("INSERT OR IGNORE INTO schema_migrations VALUES(1,?,?)",
                    (datetime.now().isoformat(timespec="seconds"), "V3.6 additive QC tables"))
        con.commit()

def compliance_metrics(audit: dict) -> dict:
    matches = audit.get("matches", pd.DataFrame())
    details = audit.get("details", pd.DataFrame())
    ok = mismatch = 0
    if isinstance(matches, pd.DataFrame) and not matches.empty:
        for c in matches.columns:
            if c.endswith(" Status"):
                s = matches[c].astype(str).str.upper()
                ok += int(s.eq("OK").sum())
                mismatch += int(s.eq("MISMATCH").sum())
    missing = int(audit.get("missing", 0))
    extra = int(audit.get("extra", 0))
    duplicate = 0
    if isinstance(details, pd.DataFrame) and not details.empty and "Audit Status" in details:
        duplicate = int(details["Audit Status"].astype(str).str.contains("DUPLICATE", case=False).sum())
    checks = ok + mismatch
    return {
        "matched_checks": ok, "mismatched_checks": mismatch,
        "valid_checks": checks,
        "parameter_compliance_pct": round(ok / checks * 100, 2) if checks else None,
        "matched_cells": int(audit.get("matched", 0)),
        "missing_cells": missing, "extra_cells": extra,
        "duplicate_findings": duplicate,
        "cell_match_rate_pct": round(int(audit.get("matched", 0)) /
            max(int(audit.get("matched", 0)) + missing, 1) * 100, 2)
    }

def alarm_summary(df: pd.DataFrame) -> dict:
    if df is None or df.empty:
        return {"total": 0, "cleared": 0, "uncleared": 0, "severity": {}}
    status = df.get("Clearance Status", pd.Series("", index=df.index)).astype(str).str.strip().str.lower()
    severity = df.get("Severity", pd.Series("Unknown", index=df.index)).astype(str).str.strip()
    return {
        "total": int(len(df)),
        "cleared": int(status.eq("cleared").sum()),
        "uncleared": int(status.eq("uncleared").sum()),
        "severity": severity.value_counts(dropna=False).to_dict()
    }

def ta_summary(df: pd.DataFrame, step_m: float = 78.125) -> tuple[pd.DataFrame, dict]:
    prefix = "L.RA.TA.UE.Index"
    cols = [f"{prefix}{i}" for i in range(12) if f"{prefix}{i}" in (df.columns if df is not None else [])]
    if df is None or df.empty or not cols:
        return pd.DataFrame(columns=["TA Index", "Count", "Percentage", "Distance Midpoint (m)"]), {
            "total": 0, "dominant_index": None, "percentiles_m": {}, "step_m": float(step_m)}
    vals = df[cols].apply(pd.to_numeric, errors="coerce").fillna(0).sum()
    total = float(vals.sum())
    rows = []
    counts = []
    for i in range(12):
        count = float(vals.get(f"{prefix}{i}", 0))
        counts.append(count)
        rows.append({"TA Index": i, "Count": count,
                     "Percentage": count / total * 100 if total else 0.0,
                     "Distance Midpoint (m)": (i + 0.5) * float(step_m)})
    percentiles = {}
    if total > 0:
        cumulative = 0.0
        for pct in (50, 80, 90, 95):
            target = total * pct / 100
            cumulative = 0.0
            result = None
            for i, count in enumerate(counts):
                previous = cumulative
                cumulative += count
                if cumulative >= target and count > 0:
                    frac = (target - previous) / count
                    result = (i + min(max(frac, 0), 1)) * float(step_m)
                    break
            percentiles[f"P{pct}"] = round(result if result is not None else 12 * float(step_m), 1)
    dominant = int(max(range(12), key=lambda i: counts[i])) if total else None
    return pd.DataFrame(rows), {"total": int(total), "dominant_index": dominant,
                                "percentiles_m": percentiles, "step_m": float(step_m)}

def persist_findings(db_path: Path, run_id: str, findings: pd.DataFrame):
    if findings is None or findings.empty:
        return
    with sqlite3.connect(db_path) as con:
        for i, row in findings.iterrows():
            payload = row.to_dict()
            category = str(payload.get("Audit Status", payload.get("Category", "QC Finding")))
            severity = "HIGH" if any(x in category.upper() for x in ["MISMATCH", "MISSING", "DUPLICATE", "UNCLEARED"]) else "INFO"
            fid = hashlib.sha1(f"{run_id}|{i}|{json.dumps(payload, default=str, sort_keys=True)}".encode()).hexdigest()
            con.execute("INSERT OR REPLACE INTO audit_findings VALUES(?,?,?,?,?)",
                        (fid, run_id, category, severity, json.dumps(payload, default=str, ensure_ascii=False)))
        con.commit()

def save_approval(db_path: Path, run_id: str, reviewer: str, status: str, remarks: str = ""):
    if status not in {"APPROVED", "REJECTED", "NEEDS REVISION"}:
        raise ValueError("Invalid approval status")
    if not reviewer.strip():
        raise ValueError("Reviewer name is required")
    approval_id = hashlib.sha1(f"{run_id}|{reviewer}|{datetime.now().isoformat()}".encode()).hexdigest()
    with sqlite3.connect(db_path) as con:
        con.execute("INSERT INTO qc_approvals VALUES(?,?,?,?,?,?)",
                    (approval_id, run_id, reviewer.strip(), status, remarks.strip(),
                     datetime.now().isoformat(timespec="seconds")))
        con.commit()
    return approval_id

def latest_approval(db_path: Path, run_id: str):
    with sqlite3.connect(db_path) as con:
        row = con.execute("""SELECT reviewer,status,remarks,approved_at
            FROM qc_approvals WHERE run_id=? ORDER BY approved_at DESC LIMIT 1""", (run_id,)).fetchone()
    return row

def build_excel_report(result: dict, compliance: dict, alarm: dict, ta_table: pd.DataFrame,
                       ta_stats: dict, approval, manifest: dict) -> bytes:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils.dataframe import dataframe_to_rows
    wb = Workbook()
    ws = wb.active
    ws.title = "01 Executive Summary"
    a = result["cell_audit"]
    summary = [
        ["RAN CONCHECK QC REPORT", ""],
        ["Audit Run ID", result["run_id"]],
        ["Area", result.get("area", "")],
        ["Site Name", result["site"]],
        ["eNodeB Name", result["enodeb"]],
        ["RAT", result["rat"]],
        ["Audit Status", a.get("status")],
        ["Parameter Compliance (%)", compliance.get("parameter_compliance_pct")],
        ["Cell Match Rate (%)", compliance.get("cell_match_rate_pct")],
        ["Matched Checks", compliance.get("matched_checks")],
        ["Mismatched Checks", compliance.get("mismatched_checks")],
        ["Missing Cells", compliance.get("missing_cells")],
        ["Extra Cells", compliance.get("extra_cells")],
        ["Total Alarms", alarm.get("total")],
        ["Cleared Alarms", alarm.get("cleared")],
        ["Uncleared Alarms", alarm.get("uncleared")],
        ["TA Total Count", ta_stats.get("total")],
        ["TA Dominant Index", ta_stats.get("dominant_index")],
        ["TA Percentiles (m)", json.dumps(ta_stats.get("percentiles_m", {}))],
        ["Approval", approval[1] if approval else "PENDING"],
        ["Reviewer", approval[0] if approval else ""],
        ["Approval Remarks", approval[2] if approval else ""],
    ]
    for row in summary: ws.append(row)
    ws.freeze_panes = "A2"
    def add_df(name, df):
        sh = wb.create_sheet(name[:31])
        if df is None or df.empty:
            sh.append(["No records"])
            return
        for row in dataframe_to_rows(df, index=False, header=True): sh.append(row)
        sh.freeze_panes = "A2"
        sh.auto_filter.ref = sh.dimensions
    add_df("02 NDB RAN Findings", a.get("details"))
    add_df("03 Cell Comparison", a.get("matches"))
    add_df("04 Alarm Details", result.get("alarm_rows"))
    add_df("05 TA Distribution", ta_table)
    add_df("06 TA Raw Filtered", result.get("ta_rows"))
    add_df("07 NDB Reference", result.get("ndb_rows"))
    add_df("08 RAN Reference", result.get("ran_rows"))
    manifest_rows = [{"Category": k, "Files": ", ".join(v)} for k, v in manifest.items()]
    add_df("09 Source Manifest", pd.DataFrame(manifest_rows))
    for sh in wb.worksheets:
        sh.sheet_view.showGridLines = False
        for cell in sh[1]:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="1F4E78")
            cell.alignment = Alignment(vertical="center")
        for col in sh.columns:
            letter = col[0].column_letter
            max_len = min(max((len(str(c.value)) if c.value is not None else 0 for c in col[:300]), default=10) + 2, 48)
            sh.column_dimensions[letter].width = max(12, max_len)
    bio = BytesIO()
    wb.save(bio)
    return bio.getvalue()

def build_pdf_report(result: dict, compliance: dict, alarm: dict, ta_stats: dict, approval) -> bytes:
    from xml.sax.saxutils import escape
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
    bio = BytesIO()
    doc = SimpleDocTemplate(bio, pagesize=A4, rightMargin=16*mm, leftMargin=16*mm,
                            topMargin=15*mm, bottomMargin=15*mm)
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="SmallCell", parent=styles["BodyText"], fontSize=7, leading=9))
    story = [Paragraph("RAN CONCHECK QC REPORT", styles["Title"]),
             Paragraph(escape(f"Area: {result.get('area', '')} | Site: {result['site']} | eNodeB: {result['enodeb']} | RAT: {result['rat']}"), styles["Heading2"]),
             Paragraph(escape(f"Audit Run ID: {result['run_id']}"), styles["BodyText"]), Spacer(1, 8)]
    rows = [["Metric", "Result"],
            ["Audit Status", str(result["cell_audit"].get("status"))],
            ["Parameter Compliance", f"{compliance.get('parameter_compliance_pct')}%"],
            ["Cell Match Rate", f"{compliance.get('cell_match_rate_pct')}%"],
            ["Matched / Mismatched Checks", f"{compliance.get('matched_checks')} / {compliance.get('mismatched_checks')}"],
            ["Missing / Extra Cells", f"{compliance.get('missing_cells')} / {compliance.get('extra_cells')}"],
            ["Total / Uncleared Alarms", f"{alarm.get('total')} / {alarm.get('uncleared')}"],
            ["TA Total Count", str(ta_stats.get("total"))],
            ["TA Percentiles", json.dumps(ta_stats.get("percentiles_m", {}))],
            ["Approval", approval[1] if approval else "PENDING"],
            ["Reviewer", approval[0] if approval else ""]]
    table = Table(rows, colWidths=[65*mm, 105*mm], repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#1F4E78")),
        ("TEXTCOLOR", (0,0), (-1,0), colors.white),
        ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
        ("GRID", (0,0), (-1,-1), 0.4, colors.HexColor("#CBD5E1")),
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#F1F5F9")]),
        ("FONTSIZE", (0,0), (-1,-1), 8),
        ("LEFTPADDING", (0,0), (-1,-1), 6), ("RIGHTPADDING", (0,0), (-1,-1), 6)
    ]))
    story += [table, Spacer(1, 12), Paragraph("Configuration Findings", styles["Heading2"])]
    details = result["cell_audit"].get("details", pd.DataFrame())
    if details is None or details.empty:
        story.append(Paragraph("No configuration findings were recorded for the mapped parameters.", styles["BodyText"]))
    else:
        cols = [c for c in ["Cell Name", "Audit Status", "Parameter", "NDB Value", "RAN Value"] if c in details.columns]
        data = [[Paragraph(str(c), styles["SmallCell"]) for c in cols]]
        for _, row in details[cols].head(150).iterrows():
            data.append([Paragraph(escape(str(row[c])[:160]), styles["SmallCell"]) for c in cols])
        widths = [34*mm, 38*mm, 28*mm, 34*mm, 34*mm][:len(cols)]
        t = Table(data, colWidths=widths, repeatRows=1)
        t.setStyle(TableStyle([
            ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#334155")),
            ("TEXTCOLOR", (0,0), (-1,0), colors.white),
            ("GRID", (0,0), (-1,-1), 0.3, colors.HexColor("#CBD5E1")),
            ("VALIGN", (0,0), (-1,-1), "TOP"),
            ("FONTSIZE", (0,0), (-1,-1), 7)
        ]))
        story.append(t)
        if len(details) > 150:
            story.append(Paragraph(f"Showing first 150 of {len(details)} findings. Full detail is available in the Excel report.", styles["Italic"]))
    story += [Spacer(1, 12), Paragraph("Alarm Summary", styles["Heading2"]),
              Paragraph(f"Total: {alarm.get('total')} | Cleared: {alarm.get('cleared')} | Uncleared: {alarm.get('uncleared')}", styles["BodyText"]),
              Spacer(1, 8), Paragraph("TA Analysis", styles["Heading2"]),
              Paragraph(f"Dominant TA Index: {ta_stats.get('dominant_index')} | Percentiles (m): {json.dumps(ta_stats.get('percentiles_m', {}))}", styles["BodyText"]),
              Spacer(1, 12), Paragraph("Approval & QC Remarks", styles["Heading2"]),
              Paragraph(f"Status: {approval[1] if approval else 'PENDING'}", styles["BodyText"]),
              Paragraph(escape(f"Reviewer: {approval[0] if approval else ''}"), styles["BodyText"]),
              Paragraph(escape(f"Remarks: {approval[2] if approval else ''}"), styles["BodyText"]),
              Spacer(1, 16), Paragraph("This report is generated from the recorded audit snapshot. TA distance values are estimates based on the configured bin step and do not represent individual UE GPS positions.", styles["Italic"])]
    doc.build(story)
    return bio.getvalue()
