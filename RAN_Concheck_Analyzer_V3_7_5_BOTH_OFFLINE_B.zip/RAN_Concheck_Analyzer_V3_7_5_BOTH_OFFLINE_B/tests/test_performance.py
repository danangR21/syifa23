import ast
import unittest
from pathlib import Path

APP = Path(__file__).resolve().parents[1] / "app.py"

class PerformanceRegressionTests(unittest.TestCase):
    def test_scan_does_not_read_dump_workbooks(self):
        tree = ast.parse(APP.read_text(encoding="utf-8"))
        scan_if = next((n for n in tree.body if isinstance(n, ast.If) and isinstance(n.test, ast.Name) and n.test.id == "scan"), None)
        self.assertIsNotNone(scan_if, "SCAN SITE handler not found")
        calls = [n for n in ast.walk(scan_if) if isinstance(n, ast.Call)]
        called_names = [n.func.id for n in calls if isinstance(n.func, ast.Name)]
        self.assertFalse(any("dump" in name.lower() for name in called_names), called_names)

    def test_dump_viewer_uses_search_first_workflow(self):
        source = APP.read_text(encoding="utf-8")
        self.assertIn("SEARCH COMMAND", source)
        self.assertIn("dump_command_catalog_cached(signature)", source)
        self.assertIn("load_one_dump_command(selected,site,enodeb)", source)
        self.assertIn("with st.form(key=f\"dump_search_form_{run_id}\")", source)
        self.assertNotIn("load_dump_frames_cached", source)
        self.assertNotIn("load_dump_frames()", source)

    def test_dump_catalog_reads_sheet_metadata_not_all_rows(self):
        source = APP.read_text(encoding="utf-8")
        self.assertIn("_xlsx_sheet_targets(p)", source)
        self.assertIn("xl/workbook.xml", source)
        self.assertIn("Parse only the selected XLSX worksheet XML", source)

if __name__ == "__main__":
    unittest.main()
