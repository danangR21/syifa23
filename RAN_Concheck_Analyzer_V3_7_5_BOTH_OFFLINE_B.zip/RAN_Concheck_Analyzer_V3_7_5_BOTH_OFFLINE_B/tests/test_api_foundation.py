from types import SimpleNamespace

from fastapi.testclient import TestClient

from api.main import app


def test_health_and_version_are_available():
    client = TestClient(app)
    health = client.get("/health")
    assert health.status_code == 200
    assert health.json()["status"] == "ok"
    version = client.get("/api/v1/version")
    assert version.status_code == 200
    assert version.json()["version"] == "3.7.5"


def test_protected_endpoint_fails_closed_without_server_token(monkeypatch):
    from api import main

    monkeypatch.setattr(
        main, "settings",
        SimpleNamespace(api_token="", app_version="3.7.5")
    )
    client = TestClient(app)
    response = client.get("/api/v1/me")
    assert response.status_code == 503
