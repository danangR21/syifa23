import sqlite3
import tempfile
import unittest
from pathlib import Path
import pandas as pd
from modules.v36_features import (migrate_schema, compliance_metrics, alarm_summary,
    ta_summary, save_approval, latest_approval, build_excel_report, build_pdf_report)

class V36FeatureTests(unittest.TestCase):
    def setUp(self):
        self.db = Path(tempfile.mkdtemp()) / "history.db"
        with sqlite3.connect(self.db) as con:
            con.execute("CREATE TABLE audit_runs(run_id TEXT PRIMARY KEY, scanned_at TEXT, site_name TEXT, enodeb_name TEXT, alarm_source TEXT, ndb_status TEXT, ran_status TEXT, ndb_cells INTEGER, ran_cells INTEGER, matched_cells INTEGER, mismatch_cells INTEGER, alarm_rows INTEGER, uncleared_alarms INTEGER, ta_rows INTEGER, source_manifest TEXT)")
        migrate_schema(self.db)

    def test_compliance(self):
        a={"matches":pd.DataFrame({"PCI Status":["OK","MISMATCH"],"TAC Status":["OK","OK"]}),"details":pd.DataFrame(),"matched":2,"missing":1,"extra":0}
        m=compliance_metrics(a)
        self.assertEqual(m["matched_checks"],3)
        self.assertEqual(m["mismatched_checks"],1)
        self.assertEqual(m["parameter_compliance_pct"],75.0)

    def test_alarm_and_ta(self):
        a=alarm_summary(pd.DataFrame({"Clearance Status":["Cleared","Uncleared"],"Severity":["Major","Critical"]}))
        self.assertEqual(a["uncleared"],1)
        p="L.RA.TA.UE.Index"
        df=pd.DataFrame({f"{p}{i}":[10 if i==0 else 5 if i==1 else 0] for i in range(12)})
        table,stats=ta_summary(df,78.125)
        self.assertEqual(stats["total"],15)
        self.assertEqual(stats["dominant_index"],0)
        self.assertIn("P90",stats["percentiles_m"])

    def test_approval(self):
        save_approval(self.db,"RUN1","QC Reviewer","APPROVED","Checked")
        self.assertEqual(latest_approval(self.db,"RUN1")[1],"APPROVED")

if __name__ == "__main__":
    unittest.main()
