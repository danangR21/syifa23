Run regression tests from this folder's parent directory:
  python -m unittest discover -s tests -v

Tests cover deterministic QC helpers and the V3.6.3 search-only Dump Config workflow.
