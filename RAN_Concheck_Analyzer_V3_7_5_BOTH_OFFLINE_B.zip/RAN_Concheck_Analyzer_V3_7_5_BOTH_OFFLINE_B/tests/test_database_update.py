import zipfile
from pathlib import Path
import pytest

from core.database_update import validate_snapshot_zip, activate_snapshot, SnapshotError, REQUIRED_FOLDERS

def make_zip(path: Path, include_all=True):
    with zipfile.ZipFile(path, "w") as z:
        folders = sorted(REQUIRED_FOLDERS) if include_all else ["01_NDB"]
        for folder in folders:
            z.writestr(f"database_Concheck/{folder}/sample.csv", "A,B\\n1,2\\n")

def test_validate_snapshot(tmp_path):
    p = tmp_path / "snapshot.zip"
    make_zip(p)
    report = validate_snapshot_zip(p)
    assert report.file_count == 5
    assert all(v == 1 for v in report.category_counts.values())

def test_reject_missing_categories(tmp_path):
    p = tmp_path / "bad.zip"
    make_zip(p, include_all=False)
    with pytest.raises(SnapshotError):
        validate_snapshot_zip(p)

def test_reject_path_traversal(tmp_path):
    p = tmp_path / "traversal.zip"
    with zipfile.ZipFile(p, "w") as z:
        z.writestr("database_Concheck/01_NDB/../../evil.csv", "x")
    with pytest.raises(SnapshotError):
        validate_snapshot_zip(p)

def test_activation_keeps_previous_snapshot(tmp_path):
    p = tmp_path / "snapshot.zip"
    make_zip(p)
    active = tmp_path / "database_Concheck"
    (active / "01_NDB").mkdir(parents=True)
    (active / "01_NDB" / "old.csv").write_text("old", encoding="utf-8")
    result = activate_snapshot(p, active)
    assert result["status"] == "activated"
    assert (active / "01_NDB" / "sample.csv").exists()
    assert (tmp_path / "database_Concheck.previous" / "01_NDB" / "old.csv").exists()
