Edit audit_rules.json only after confirming the operational field mapping. Source data remains read-only.
