"""Dark Enterprise design system. Presentation-only; does not touch data engines."""
import streamlit as st


def apply_workbench_theme():
    st.markdown("""
    <style>
    :root { --ran-bg:#0b1220; --ran-panel:#111d2d; --ran-panel-2:#17263a;
      --ran-line:#26384d; --ran-text:#e7eef7; --ran-muted:#9aadc2;
      --ran-cyan:#32c5e8; --ran-blue:#3987ff; --ran-green:#27c28a; }
    .stApp { background: radial-gradient(ellipse at 78% -12%, rgba(24,105,145,.16), transparent 38%), var(--ran-bg); color:var(--ran-text); }
    [data-testid="stHeader"] { background:rgba(11,18,32,.82); }
    [data-testid="stSidebar"] { background:linear-gradient(180deg,#101c2c 0%,#0c1625 100%); border-right:1px solid var(--ran-line); }
    [data-testid="stSidebar"] [data-testid="stMarkdownContainer"] p { color:#c6d4e3; }
    h1,h2,h3 { letter-spacing:-.025em; }
    h1 { font-weight:800 !important; }
    [data-testid="stMetric"] { background:linear-gradient(145deg,#142338,#101b2b); border:1px solid #263b53; padding:14px 16px; border-radius:13px; }
    [data-testid="stMetricLabel"] { color:#9fb5ca !important; }
    [data-testid="stMetricValue"] { color:#f2f7fc !important; }
    .ran-status-metric { min-height:98px; box-sizing:border-box; padding:14px 16px;
      border-radius:13px; border:1px solid #263b53; background:linear-gradient(145deg,#142338,#101b2b); }
    .ran-status-label { color:#9fb5ca; font-size:14px; line-height:1.35; margin-bottom:12px; }
    .ran-status-value { color:#f2f7fc; font-size:32px; line-height:1.1; font-weight:600; letter-spacing:-.025em; }
    .ran-status-metric.success { border-color:rgba(39,194,138,.48); background:linear-gradient(145deg,rgba(16,65,55,.62),#101b2b); }
    .ran-status-metric.success .ran-status-value { color:#55d6a5; }
    .ran-status-metric.error { border-color:rgba(239,83,80,.48); background:linear-gradient(145deg,rgba(75,31,39,.62),#101b2b); }
    .ran-status-metric.error .ran-status-value { color:#ff8585; }
    .ran-status-metric.warning { border-color:rgba(230,166,65,.48); background:linear-gradient(145deg,rgba(78,57,27,.62),#101b2b); }
    .ran-status-metric.warning .ran-status-value { color:#f2c36d; }
    div[data-testid="stTabs"] button { border-radius:9px 9px 0 0; font-weight:650; }
    div[data-testid="stTabs"] button[aria-selected="true"] { color:#4bd3f0 !important; border-bottom-color:#32c5e8 !important; }
    div[data-testid="stForm"] { background:#111d2d; border:1px solid #26384d; border-radius:13px; padding:14px; }
    div[data-testid="stDataFrame"] { border:1px solid #2b4057; border-radius:10px; overflow:hidden; }
    div.stButton > button[kind="primary"], div.stFormSubmitButton > button[kind="primary"] { background:linear-gradient(100deg,#087fa5,#1765b8); border:1px solid #28b5d8; color:white; font-weight:750; border-radius:9px; }
    div.stButton > button { border-radius:9px; }
    [data-testid="stExpander"] { border:1px solid #2a3e54; border-radius:11px; }
    [data-testid="stSelectbox"] > div, [data-testid="stTextInput"] > div { border-radius:9px; }
    .ran-brand { display:flex; align-items:center; gap:11px; padding:13px 12px; margin:0 0 16px 0;
      background:linear-gradient(120deg,rgba(20,57,82,.95),rgba(17,29,45,.95)); border:1px solid #2b5067; border-radius:13px; }
    .ran-brand-icon { width:39px;height:39px;display:flex;align-items:center;justify-content:center;border-radius:11px;
      color:#71e4fa;background:rgba(50,197,232,.13);font-size:23px; }
    .ran-brand-title { color:#f3f8fc;font-size:14px;font-weight:850;letter-spacing:.045em;line-height:1.25; }
    .ran-brand-sub { color:#9eb8cb;font-size:9px;letter-spacing:.13em;margin-top:3px; }
    .ran-hero { padding:21px 24px; border:1px solid #29465e; border-radius:16px; margin:0 0 18px 0;
      background:linear-gradient(112deg,#10243a 0%,#123a57 58%,#075b70 100%); box-shadow:0 12px 30px rgba(0,0,0,.16); }
    .ran-kicker { color:#65d9ef;font-size:10px;font-weight:850;letter-spacing:.19em;text-transform:uppercase; }
    .ran-hero-title { color:#f6fbff;font-size:27px;font-weight:850;letter-spacing:-.035em;margin:5px 0 3px; }
    .ran-hero-sub { color:#bdd3e3;font-size:12px; }
    .ran-chip { display:inline-block;padding:5px 9px;margin:12px 6px 0 0;border:1px solid rgba(179,229,245,.24);border-radius:20px;
      color:#dff8ff;background:rgba(255,255,255,.07);font-size:10px;font-weight:700; }
    .ran-section-label { color:#55cce7;font-size:11px;font-weight:850;letter-spacing:.14em;text-transform:uppercase;margin:8px 0 10px; }
    .ran-muted { color:#9aadc2;font-size:11px; }
    @media (max-width: 900px) { .ran-hero-title{font-size:22px;} }
    </style>
    """, unsafe_allow_html=True)


def render_brand_header(version="V3.7 FOUNDATION"):
    st.markdown(f"""
    <div class="ran-hero">
      <div class="ran-kicker">TELECOM ENGINEERING PLATFORM · DARK ENTERPRISE</div>
      <div class="ran-hero-title">RAN Configuration Workbench</div>
      <div class="ran-hero-sub">Explore · Compare · Audit · Visualize · Report</div>
      <span class="ran-chip">◉ 4G LTE</span><span class="ran-chip">◉ 5G NR</span>
      <span class="ran-chip">⌁ RF ENGINEERING</span><span class="ran-chip">▣ READ-ONLY SOURCE</span>
      <span class="ran-chip">{version}</span>
    </div>
    """, unsafe_allow_html=True)


def render_sidebar_brand():
    st.markdown("""
    <div class="ran-brand">
      <div class="ran-brand-icon">⌁</div>
      <div><div class="ran-brand-title">RAN CONCHECK</div>
      <div class="ran-brand-sub">CONFIGURATION WORKBENCH</div></div>
    </div>
    """, unsafe_allow_html=True)
