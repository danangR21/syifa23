# Android Offline Foundation (development scaffold; not production-certified)

## Implemented in this increment
- Native Android launcher shell.
- ZIP picker via Android Storage Access Framework.
- Snapshot structure, extension, path traversal and category checks.
- SHA-256 computed as a stream.
- Staged extraction into app-private storage.
- Activation with previous-snapshot backup and rollback attempt.
- Separate app-private SQLite schema for audit runs and QC approvals.

## Not yet implemented / verified
- Android QC execution parity with Windows.
- Complete SCAN SITE, NDB/RAN compare, Dump, Alarm, TA workflows.
- Full manual identity-conflict review and QC approval workflow.
- Excel/PDF report generation.
- Gradle build, APK signing, installation and physical-device tests.

This is a development scaffold, not an installable deliverable. Do not distribute as a production QC app until the remaining gates pass.
