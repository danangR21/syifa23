# Build APK without Android Studio

This project includes a GitHub Actions workflow at
`.github/workflows/android-debug-apk.yml`.

## Steps
1. Create a **private** GitHub repository.
2. Upload/push the contents of this source package to the repository root.
3. Open the repository's Actions tab.
4. Select **Build RAN Concheck Android APK**.
5. Select **Run workflow** and wait for the job to finish successfully.
6. Open the completed workflow run and download artifact
   `RAN_Concheck_Offline-Android14plus-debug`.
7. Extract the artifact ZIP. The APK inside is `app-debug.apk`.
8. Transfer the APK to the Android phone and install it.

## Important
- The workflow creates a debug APK, automatically signed with the standard
  Android debug key so it can be installed for testing.
- This is not a production/release signing key. Do not use debug signing
  for public distribution.
- The current Android app is still a development scaffold. The build only
  makes the shell/import-validation foundation installable; it does NOT
  mean all Desktop QC features are implemented on Android.
- Do not commit operator datasets, source reports, SQLite history, API
  tokens, or private signing keys to GitHub. Keep the repository private.
- If the repository belongs to a company, confirm company authorization
  before uploading any company source or data.
