package com.ranconcheck.offline

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.zip.ZipFile

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val requestZip = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
        }
        root.addView(TextView(this).apply {
            text = "RAN CONCHECK OFFLINE"
            textSize = 22f
        })
        status = TextView(this).apply {
            text = "Database lokal belum diperiksa."
            textSize = 15f
            setPadding(0, 24, 0, 24)
        }
        root.addView(status)
        root.addView(Button(this).apply {
            text = "IMPORT DATABASE UPDATE"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/zip"
                }
                startActivityForResult(intent, requestZip)
            }
        })
        root.addView(TextView(this).apply {
            text = "Mode offline • Data tersimpan di perangkat ini"
            textSize = 12f
            setPadding(0, 24, 0, 0)
        })
        setContentView(root)
    }

    @Deprecated("Deprecated in Android API, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != requestZip || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try {
            val staged = File(cacheDir, "incoming_snapshot.zip")
            contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Tidak dapat membaca file." }
                FileOutputStream(staged).use { output -> input.copyTo(output) }
            }
            val checked = validateZip(staged)
            status.text = "VALID • ${checked.first} file • SHA256 ${checked.second.take(12)}…\nBelum diaktifkan: QC parity dan aktivasi final masih tahap implementasi."
            Toast.makeText(this, "Snapshot lolos pemeriksaan struktur", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            status.text = "UPDATE DITOLAK: ${e.message}"
            Toast.makeText(this, "Database update gagal divalidasi", Toast.LENGTH_LONG).show()
        }
    }

    private fun validateZip(file: File): Pair<Int, String> {
        val required = setOf("01_NDB", "02_RAN_Report", "03_Dump_Config", "04_Alarm", "05_TA")
        val found = mutableSetOf<String>()
        var count = 0
        ZipFile(file).use { zip ->
            val entries = zip.entries()
            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                if (entry.isDirectory) continue
                val parts = entry.name.split("/")
                require(!entry.name.startsWith("/") && !parts.contains("..")) { "Path ZIP tidak aman." }
                require(parts.size >= 3 && parts[0] == "database_Concheck") { "Struktur snapshot tidak sesuai." }
                require(parts[2].substringAfterLast('.', "").lowercase() in setOf("xlsx", "xlsm", "xls", "csv")) { "Ekstensi file tidak didukung." }
                found.add(parts[1])
                count++
                require(count <= 5000) { "Jumlah file terlalu banyak." }
            }
        }
        require(found.containsAll(required)) { "Ada kategori database yang belum lengkap." }
        val digest = MessageDigest.getInstance("SHA-256").digest(file.readBytes()).joinToString("") { "%02x".format(it) }
        return Pair(count, digest)
    }
}
