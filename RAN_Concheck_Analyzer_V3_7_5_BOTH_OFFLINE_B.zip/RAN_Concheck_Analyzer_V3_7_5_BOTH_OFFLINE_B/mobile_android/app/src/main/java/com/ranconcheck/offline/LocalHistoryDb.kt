package com.ranconcheck.offline

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Device-local audit history, separate from imported source snapshots. */
class LocalHistoryDb(context: Context) : SQLiteOpenHelper(
    context, "ran_concheck_history.db", null, 1
) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE audit_runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_uuid TEXT NOT NULL UNIQUE,
                site_name TEXT NOT NULL,
                enodeb TEXT,
                rat TEXT,
                status TEXT NOT NULL,
                source_snapshot_sha256 TEXT,
                created_at_utc TEXT NOT NULL,
                result_json TEXT NOT NULL
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE qc_approvals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_uuid TEXT NOT NULL,
                reviewer TEXT NOT NULL,
                decision TEXT NOT NULL,
                remark TEXT,
                created_at_utc TEXT NOT NULL
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX idx_audit_runs_site ON audit_runs(site_name)")
        db.execSQL("CREATE INDEX idx_qc_approvals_run ON qc_approvals(run_uuid)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Additive migrations only; never drop audit history automatically.
    }
}
