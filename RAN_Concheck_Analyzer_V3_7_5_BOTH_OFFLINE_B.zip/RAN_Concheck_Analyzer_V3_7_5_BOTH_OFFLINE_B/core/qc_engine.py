"""Streamlit-independent QC comparison primitives copied from V3.7.4.
Keep behavior aligned with app.py until golden parity tests approve changes.
"""
from __future__ import annotations
import re
import pandas as pd

def norm(value):
    if pd.isna(value):
        return ""
    return re.sub(r"\\s+", " ", str(value).strip()).upper()

def site_base(value):
    return re.sub(r"_(2G|3G|4G|5G)$", "", norm(value))

def is_blank(value):
    return pd.isna(value) or str(value).strip() in {"", "-", "NULL", "nan", "None"}

def same_value(a, b):
    if is_blank(a) and is_blank(b):
        return True
    if is_blank(a) != is_blank(b):
        return False
    try:
        fa, fb = float(str(a).replace(",", "")), float(str(b).replace(",", ""))
        return abs(fa-fb) < 1e-8
    except Exception:
        return norm(a) == norm(b)

def infer_rat(enodeb, ndb_rows):
    value = norm(enodeb)
    if value.endswith("_5G"):
        return "5G"
    if value.endswith("_4G"):
        return "4G"
    if value.endswith("_2G"):
        return "2G"
    info = " ".join(ndb_rows.get("CELL_SYSTEM_INFO", pd.Series(dtype=str)).fillna("").astype(str).tolist()).upper()
    if "5G" in info:
        return "5G"
    if "LTE" in info:
        return "4G"
    return "2G"

def filter_ndb(ndb, site, enodeb):
    if ndb.empty:
        return ndb.copy()
    d = ndb[ndb["SITE_NAME"].astype(str).map(norm) == norm(site)].copy()
    if "NE_NAME" in d.columns and enodeb:
        exact = d[d["NE_NAME"].astype(str).map(norm) == norm(enodeb)]
        if not exact.empty:
            d = exact
    return d

def filter_ran(ran, rat, site, enodeb):
    if ran.empty:
        return ran.copy()
    if rat == "4G":
        ne_col, func_col = "LTE NE Name", "eNodeB Function Name"
    elif rat == "5G":
        ne_col, func_col = "NR NE Name", "gNodeB Function Name"
    else:
        ne_col, func_col = "Site Name", "NE Name"
    d = ran.copy()
    if rat == "2G" and "Site Name" in d.columns:
        exact = d[d["Site Name"].astype(str).str.contains(re.escape(str(site)), case=False, na=False)]
        if not exact.empty:
            return exact
    if func_col in d.columns and enodeb:
        exact = d[d[func_col].astype(str).map(norm) == norm(enodeb)]
        if not exact.empty:
            return exact
    if ne_col in d.columns:
        exact = d[d[ne_col].astype(str).map(lambda x: site_base(x)) == site_base(site)]
        if not exact.empty:
            return exact
    if "Cell Name" in d.columns:
        return d[d["Cell Name"].astype(str).str.contains(re.escape(str(site).split("_")[0]), case=False, na=False)]
    return d.iloc[0:0]

def cell_match_key(value):
    value = norm(value)
    value = re.sub(r"_XY$", "", value)
    match = re.search(r"((?:L\\d+|5G\\d+|G)_[A-Z]?\\d{1,2})$", value)
    return match.group(1) if match else value

def compare_ndb_ran(ndb_rows, ran_rows, rat):
    empty = pd.DataFrame()
    if ndb_rows.empty:
        return {"status":"NOT FOUND","details":empty,"matches":empty,"matched":0,"mismatch":0,"missing":0,"extra":len(ran_rows)}
    if ran_rows.empty:
        return {"status":"INCOMPLETE","details":empty,"matches":empty,"matched":0,"mismatch":0,"missing":len(ndb_rows),"extra":0}
    n, r = ndb_rows.copy(), ran_rows.copy()
    n["_key"] = n["CELL_NAME"].astype(str).map(cell_match_key)
    r["_key"] = r["Cell Name"].astype(str).map(cell_match_key)
    rmap = {key: group.iloc[0] for key, group in r.groupby("_key", sort=False)}
    nkeys, rkeys = set(n["_key"]), set(r["_key"])
    details, match_rows = [], []
    field_map = ([("TAC_4G","TAC","TAC"),("PCI","Physical Cell ID","PCI"),
                  ("EARFCN_DL","DLEARFCN" if rat=="4G" else "DLNARFCN","EARFCN")]
                 if rat in {"4G","5G"} else
                 [("LAC","LAC","LAC"),("BCCH__OR__TRX1_Freq","BCCHNO","BCCH")])
    matched = mismatch = missing = 0
    for key, count in n["_key"].value_counts().items():
        if count > 1:
            mismatch += 1
            details.append({"Cell Name":key,"Audit Status":"DUPLICATE IN NDB","Parameter":"Cell identity key","NDB Value":f"{count} records","RAN Value":None})
    for key, count in r["_key"].value_counts().items():
        if count > 1:
            mismatch += 1
            details.append({"Cell Name":key,"Audit Status":"DUPLICATE IN RAN REPORT","Parameter":"Cell identity key","NDB Value":None,"RAN Value":f"{count} records"})
    for _, nr in n.iterrows():
        key = nr["_key"]
        if key not in rmap:
            missing += 1
            details.append({"Cell Name":nr.get("CELL_NAME"),"Audit Status":"MISSING IN RAN REPORT","Parameter":"Cell identity key","NDB Value":nr.get("CELL_NAME"),"RAN Value":None})
            continue
        rr = rmap[key]
        matched += 1
        row = {"Cell Match Key":key,"NDB Cell Name":nr.get("CELL_NAME"),"RAN Cell Name":rr.get("Cell Name"),
               "Name Mapping":"Exact" if norm(nr.get("CELL_NAME")) == norm(rr.get("Cell Name")) else "Alias / naming variation"}
        cell_status = []
        for ncol, rcol, label in field_map:
            if ncol not in n.columns or rcol not in rr.index:
                continue
            nv, rv = nr.get(ncol), rr.get(rcol)
            if is_blank(nv):
                row[f"{label} Status"] = "Not in NDB"
                row[f"NDB {label}"], row[f"RAN {label}"] = nv, rv
                continue
            ok = same_value(nv, rv)
            row[f"NDB {label}"], row[f"RAN {label}"] = nv, rv
            row[f"{label} Status"] = "OK" if ok else "MISMATCH"
            cell_status.append(ok)
            if not ok:
                mismatch += 1
                details.append({"Cell Name":nr.get("CELL_NAME"),"Audit Status":"PARAMETER MISMATCH","Parameter":label,"NDB Value":nv,"RAN Value":rv})
        row["Cell Audit"] = "OK" if all(cell_status) else "PARAMETER MISMATCH"
        match_rows.append(row)
    extra = 0
    for _, rr in r.iterrows():
        if rr["_key"] not in nkeys:
            extra += 1
            details.append({"Cell Name":rr.get("Cell Name"),"Audit Status":"EXTRA IN RAN REPORT","Parameter":"Cell identity key","NDB Value":None,"RAN Value":rr.get("Cell Name")})
    status = "MISMATCH" if missing or extra or mismatch else "OK"
    return {"status":status,"details":pd.DataFrame(details),"matches":pd.DataFrame(match_rows),
            "matched":matched,"mismatch":mismatch,"missing":missing,"extra":extra}
