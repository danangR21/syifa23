from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

ALLOWED_EXTENSIONS = {".xlsx", ".xlsm", ".xls", ".csv"}
REQUIRED_FOLDERS = {
    "01_NDB", "02_RAN_Report", "03_Dump_Config", "04_Alarm", "05_TA"
}
MAX_FILES = 5000
MAX_UNCOMPRESSED_BYTES = 5 * 1024**3

class SnapshotError(ValueError):
    pass

@dataclass(frozen=True)
class SnapshotValidation:
    file_count: int
    total_bytes: int
    category_counts: dict[str, int]
    sha256: str

def _safe_member(name: str) -> PurePosixPath:
    p = PurePosixPath(name)
    if p.is_absolute() or ".." in p.parts or not p.parts:
        raise SnapshotError(f"Unsafe archive path: {name}")
    if "\\\\" in name or ":" in name:
        raise SnapshotError(f"Invalid archive path: {name}")
    return p

def validate_snapshot_zip(zip_path: Path) -> SnapshotValidation:
    zip_path = Path(zip_path)
    if not zip_path.is_file() or not zipfile.is_zipfile(zip_path):
        raise SnapshotError("File update bukan ZIP yang valid.")
    counts = {name: 0 for name in REQUIRED_FOLDERS}
    total = 0
    files = 0
    with zipfile.ZipFile(zip_path) as archive:
        infos = archive.infolist()
        for info in infos:
            member = _safe_member(info.filename)
            if info.is_dir():
                continue
            files += 1
            total += info.file_size
            if files > MAX_FILES or total > MAX_UNCOMPRESSED_BYTES:
                raise SnapshotError("Snapshot melewati batas jumlah file atau ukuran.")
            if info.flag_bits & 0x1:
                raise SnapshotError("ZIP terenkripsi tidak didukung.")
            if len(member.parts) < 3 or member.parts[0] != "database_Concheck":
                raise SnapshotError("Struktur ZIP harus dimulai dari database_Concheck/<kategori>/...")
            category = member.parts[1]
            if category not in REQUIRED_FOLDERS:
                raise SnapshotError(f"Folder kategori tidak dikenal: {category}")
            if Path(member.name).suffix.lower() not in ALLOWED_EXTENSIONS:
                raise SnapshotError(f"Format file tidak didukung: {member.name}")
            counts[category] += 1
        missing = [name for name, count in counts.items() if count == 0]
        if missing:
            raise SnapshotError("Kategori kosong/tidak ditemukan: " + ", ".join(missing))
    digest = hashlib.sha256(zip_path.read_bytes()).hexdigest()
    return SnapshotValidation(files, total, counts, digest)

def activate_snapshot(zip_path: Path, active_root: Path) -> dict:
    """Extract to staging, validate, then swap active data with rollback on failure."""
    zip_path, active_root = Path(zip_path), Path(active_root)
    report = validate_snapshot_zip(zip_path)
    active_root.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix="ran_snapshot_stage_", dir=active_root.parent))
    backup = active_root.with_name(active_root.name + ".previous")
    try:
        with zipfile.ZipFile(zip_path) as archive:
            for info in archive.infolist():
                if info.is_dir():
                    continue
                rel = _safe_member(info.filename)
                target = staging.joinpath(*rel.parts)
                target.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(info) as src, target.open("wb") as dst:
                    shutil.copyfileobj(src, dst)
        staged_root = staging / "database_Concheck"
        for category in REQUIRED_FOLDERS:
            if not (staged_root / category).is_dir():
                raise SnapshotError(f"Folder hasil ekstraksi tidak ada: {category}")
        # Preserve previous snapshot until the new one is fully staged.
        if backup.exists():
            shutil.rmtree(backup)
        if active_root.exists():
            os.replace(active_root, backup)
        try:
            os.replace(staged_root, active_root)
        except Exception:
            if backup.exists() and not active_root.exists():
                os.replace(backup, active_root)
            raise
        return {
            "status": "activated",
            "activated_at_utc": datetime.now(timezone.utc).isoformat(),
            "file_count": report.file_count,
            "category_counts": report.category_counts,
            "sha256": report.sha256,
            "previous_snapshot_retained": backup.exists(),
        }
    finally:
        shutil.rmtree(staging, ignore_errors=True)
