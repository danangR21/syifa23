"""Shared foundation services for RAN Concheck BOTH."""
