from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


def _path_from_env(name: str, default: Path) -> Path:
    value = os.getenv(name, "").strip()
    return Path(value).expanduser().resolve() if value else default.resolve()


@dataclass(frozen=True)
class Settings:
    """Runtime paths; defaults preserve the original V3.7.4 folder layout."""

    app_root: Path
    data_root: Path
    output_root: Path
    sqlite_history_path: Path
    log_dir: Path
    api_token: str
    app_version: str


def load_settings() -> Settings:
    root = Path(__file__).resolve().parents[1]
    return Settings(
        app_root=root,
        data_root=_path_from_env("RAN_DATA_ROOT", root / "database_Concheck"),
        output_root=_path_from_env("RAN_OUTPUT_ROOT", root / "output_Concheck"),
        sqlite_history_path=_path_from_env(
            "RAN_SQLITE_HISTORY", root / "database" / "concheck_history.db"
        ),
        log_dir=_path_from_env("RAN_LOG_DIR", root / "logs"),
        api_token=os.getenv("RAN_API_TOKEN", "").strip(),
        app_version="3.7.5",
    )


settings = load_settings()
