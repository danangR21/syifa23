-- RAN Concheck BOTH — PostgreSQL metadata schema proposal (V1)
-- NOT automatically executed by V3.7.5. Review and apply only in the VPS migration phase.
-- Existing SQLite database/concheck_history.db is preserved and remains authoritative
-- for legacy V3.7.4 audit history until an explicit migration is approved.

CREATE TABLE IF NOT EXISTS app_users (
    user_id UUID PRIMARY KEY,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('admin', 'rf_engineer', 'reviewer', 'read_only')),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS app_sessions (
    session_id UUID PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES app_users(user_id),
    token_hash TEXT NOT NULL UNIQUE,
    expires_at TIMESTAMPTZ NOT NULL,
    revoked_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_jobs (
    job_id UUID PRIMARY KEY,
    requested_by UUID REFERENCES app_users(user_id),
    site_name TEXT NOT NULL,
    enodeb_name TEXT,
    status TEXT NOT NULL CHECK (status IN ('queued', 'running', 'succeeded', 'failed', 'cancelled')),
    request_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    result_json JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS source_upload_versions (
    upload_id UUID PRIMARY KEY,
    category TEXT NOT NULL,
    original_filename TEXT NOT NULL,
    stored_path TEXT NOT NULL,
    sha256 TEXT NOT NULL,
    validation_status TEXT NOT NULL CHECK (validation_status IN ('pending', 'valid', 'rejected', 'active')),
    uploaded_by UUID REFERENCES app_users(user_id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS api_audit_events (
    event_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    actor_user_id UUID REFERENCES app_users(user_id),
    action TEXT NOT NULL,
    resource_type TEXT,
    resource_id TEXT,
    details JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_audit_jobs_status_created
    ON audit_jobs(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_api_audit_events_created
    ON api_audit_events(created_at DESC);
