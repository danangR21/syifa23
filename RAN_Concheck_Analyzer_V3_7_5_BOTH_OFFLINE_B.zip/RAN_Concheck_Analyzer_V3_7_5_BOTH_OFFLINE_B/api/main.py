from __future__ import annotations

import hmac
from datetime import datetime, timezone

from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from core.settings import settings

app = FastAPI(
    title="RAN Concheck API",
    version=settings.app_version,
    description="Private API foundation. QC operations are added through shared service adapters.",
)
bearer = HTTPBearer(auto_error=False)


@app.get("/health", tags=["system"])
def health() -> dict:
    """Public liveness check; contains no database or operator data."""
    return {
        "status": "ok",
        "service": "ran-concheck-api",
        "version": settings.app_version,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
    }


@app.get("/api/v1/version", tags=["system"])
def version() -> dict:
    return {"application": "RAN Concheck Analyzer", "version": settings.app_version}


def require_api_token(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer),
) -> str:
    """Temporary foundation guard; production identity/RBAC is a later gated phase."""
    configured = settings.api_token
    if not configured:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="API authentication is not configured on this server.",
        )
    if credentials is None or credentials.scheme.lower() != "bearer":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Bearer token required.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    if not hmac.compare_digest(credentials.credentials, configured):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return "authenticated"


@app.get("/api/v1/me", tags=["auth"])
def current_session(_: str = Depends(require_api_token)) -> dict:
    """Protected smoke-test endpoint; not a replacement for full user login/RBAC."""
    return {"authenticated": True, "role": "foundation-token"}
