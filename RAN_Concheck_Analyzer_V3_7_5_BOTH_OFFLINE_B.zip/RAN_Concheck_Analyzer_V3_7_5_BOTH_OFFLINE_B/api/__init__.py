"""HTTP API layer for RAN Concheck BOTH."""
